<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Official Website of Pasong Camachile II</title>

</head>
<body>

<?php include '../Home/header.php'?>

<br>



<img src="../CSS/services2.jpg" width="400" height="600" class="d-block container" alt="...">

<div style="text-align: center !important;" class="container">
<br>
<p>
  <button style= "width: 80%;" class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
    <h3>Under Programs</h3>
  </button>
</p>
<div class="collapse" id="collapseExample">
  <div class="card card-body">
  	<h4>
    • Urban agriculture (three planting) <br>
	• Punlaan sa barangay <br>
	• Gulayan sa bahay <br>
	• Gulayan sa paaralan <br>
	• Gulayan sa simbahan <br>
	• Sibol para sa kabataan <br>
	</h4>
  </div>
</div>
</div>






<div style="text-align: center !important;" class="container">
<br>
<p>
  <button style= "width: 80%;" class="btn btn-primary" type="button" data-toggle="collapse" data-target="#collapseExample3" aria-expanded="false" aria-controls="collapseExample3">
    <h3>Projects</h3>
  </button>
</p>
<div class="collapse" id="collapseExample3">
  <div class="card card-body">
  	<h4>
    • Cctv <br>
	• Streetlights <br>
	• Deep well (Poso) <br>
	• Public address system <br>
	• Mamamayan Kontra Basura(MKB) <br>
	</h4>
  </div>
</div>
</div>

<br>


</body>

<?php include '../Home/footer.php' ?>

</html>