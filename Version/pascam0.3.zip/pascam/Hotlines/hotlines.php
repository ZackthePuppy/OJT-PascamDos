<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Official Website of Pasong Camachile II</title>

</head>
<body>

<?php include '../Home/header.php'?>

<br>


  <h2 style="text-align: center; font-family: ChalkFont;">Emergency Hotlines</h2>

<div class="announcement" style="background-color: #fffbcc; color: #777; font-size: 14px; line-height: 23px; padding: 13px 16px; text-align:center; margin-right: 50px; margin-left: 50px;">

  <h4 style="background-color: #f58f2a; border-radius: 3px; color: #fff; margin-left: 4px; margin-right: 4px; padding: 3px 5px 3px 4px; font-weight:bold; text-transform: uppercase;"><b>Pasong Camachile II
Brgy. Hall-Extension</b></h4>
  <h3>0977-457-5401 <br>
0977-457-5372</h3>

  <h4 style="background-color: #f58f2a; border-radius: 3px; color: #fff; margin-left: 4px; margin-right: 4px; padding: 3px 5px 3px 4px; font-weight:bold; text-transform: uppercase;"><b>Mary Cris Complex Homeowners Association Incorporated <br>
MCCHAI Ambulance and Mamayan Kontra Basura (MKB)</b></h4>
  <h3>0933-826-0890</h3>

  <h4 style="background-color: #f58f2a; border-radius: 3px; color: #fff; margin-left: 4px; margin-right: 4px; padding: 3px 5px 3px 4px; font-weight:bold; text-transform: uppercase;"><b>Philippine National Police Main Station</b></h4>
  <h3>0917-622-3320 <br>
046-513-8600 <br>
437-7306</h3>

  <h4 style="background-color: #f58f2a; border-radius: 3px; color: #fff; margin-left: 4px; margin-right: 4px; padding: 3px 5px 3px 4px; font-weight:bold; text-transform: uppercase;"><b>Philippine National Police Sub Station</b></h4>
  <h3>0917-638-8625 <br>
046-513-7058</h3>

  <h4 style="background-color: #f58f2a; border-radius: 3px; color: #fff; margin-left: 4px; margin-right: 4px; padding: 3px 5px 3px 4px; font-weight:bold; text-transform: uppercase;"><b>Bureau of Fire Protection Main Station</b></h4>
  <h3>0917-593-1522 <br>
046-513-7200 <br>
437-7625</h3>

  <h4 style="background-color: #f58f2a; border-radius: 3px; color: #fff; margin-left: 4px; margin-right: 4px; padding: 3px 5px 3px 4px; font-weight:bold; text-transform: uppercase;"><b>Bureau of Fire Protection Manggahan Station</b></h4>
  <h3>0917-653-5994 <br>
046-513-8268</h3>

  <h4 style="background-color: #f58f2a; border-radius: 3px; color: #fff; margin-left: 4px; margin-right: 4px; padding: 3px 5px 3px 4px; font-weight:bold; text-transform: uppercase;"><b>City Disaster Risk Reduction and Management Council (CDRRMO)</b></h4>
  <h3>0917-596-8676 <br>
046-513-6986 <br>
509-5068</h3>

</div>
<br>

</body>

<?php include '../Home/footer.php' ?>

</html>