<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Official Website of Pasong Camachile II</title>

</head>
<body>

<?php include '../Home/header.php'?>

<br>


<div class="announcement" style="background-color: #fffbcc; color: #777; font-size: 14px; line-height: 23px; padding: 13px 16px; text-align:center; font-family:Arial, Helvetica, sans-serif; margin-right: 50px; margin-left: 50px;">
  <h2 style="text-align: center;">Announcement</h2>
  <h5 style="background-color: #f58f2a; border-radius: 3px; color: #fff; margin-left: 4px; margin-right: 4px; padding: 3px 5px 3px 4px; font-weight:bold; text-transform: uppercase;"><b>7/21/2021</b></h5>
  <img src="../CSS/events.jpg">
  <h5 style="background-color: #f58f2a; border-radius: 3px; color: #fff; margin-left: 4px; margin-right: 4px; padding: 3px 5px 3px 4px; font-weight:bold; text-transform: uppercase;"><b>7/21/2021</b></h5>
  <p><b>Welcome! This is an unofficial website of BRGY. PASONG CAMACHILE II created by a student of Cavite State University - Imus Campus.</b></p>
</div>

</body>

<?php include '../Home/footer.php' ?>

</html>