<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Official Website of Pasong Camachile II</title>

</head>
<body>

<?php include '../Home/header.php'?>

<br>


<h1>PUT BRGY CORNER HERE</h1>








</body>

<?php include '../Home/footer.php' ?>

</html>